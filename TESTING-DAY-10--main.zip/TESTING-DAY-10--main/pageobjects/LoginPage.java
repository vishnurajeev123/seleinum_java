package pageobjects;

public class LoginPage {

}
